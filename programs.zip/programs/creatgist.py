import requests
import json

url = "https://api.github.com"

endpoint = "/gists"

finalurl = url + endpoint

username = "giridhar276"
password = "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"

print("checking ", url, "using user:", username)

local_file = "adult.csv"  # your existing filename
with open(local_file) as fh:
    mydata = fh.read()
       
payload = {
    "description": "rest api - giri testing",
    "public": "true",
    "user" : username,
    "files": {
    local_file : {
    "content": mydata
        }
      }
}
r1 = requests.post(finalurl, data=json.dumps(payload), auth=(username,password))
print(r1.json())
