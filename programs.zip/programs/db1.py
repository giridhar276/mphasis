

import pymysql

try:
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    if conn:
        print("connection is successful")
        
    else:
        print("connection failed")
except Exception as err:
    print(err)