

import pymysql

try:
    #step1 ; open the connection
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    if conn:
        print("connection is successful")
        cursor = conn.cursor()
        # step2 : define query
        query = "insert into mphasis.adultinfo values('{}','{}','{}')".format('public','inter','attender')
        # step3 : execute query
        cursor.execute(query)
        # step4 : fetch the details
        print(cursor.rowcount," record inserted")
        conn.commit()
        # close the connection
        conn.close()
        
    else:
        print("connection failed")
except Exception as err:
    print(err)