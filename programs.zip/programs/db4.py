import pymysql

try:
    #step1 ; open the connection
    username = input("Enter user name :")
    password = input('Enter password  :')
    conn = pymysql.connect(host='127.0.0.1',port=3306,user=username,password=password)
    if conn:
        print("connection is successful")
        cursor = conn.cursor()
        # step2 : define query
        query = "select * from mphasis.adultinfo"
        # step3 : execute query
        cursor.execute(query)
        # step4 : fetch the details
        for record in cursor.fetchall():
            print("Workclass :",record[0])
            print("Education :",record[1])
            print("Occupation :",record[2])
            print("--------------")
        # close the connection
       
        conn.close()
        
    else:
        print("connection failed")
except Exception as err:
    print(err)