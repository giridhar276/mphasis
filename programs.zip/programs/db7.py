
import pymysql
import os
import csv
try:
    #step1 ; open the connection
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='giri@123')
    count = 0
    if conn:
        print("connection is successful")
        cursor = conn.cursor()
        # step2 : define query
        filename = "adult.csv"
        if os.path.isfile(filename):
            with open(filename,"r") as fobj:
                # converting file object to the csv object
                csvreader = csv.reader(fobj)
                for line in csvreader:                            
                    query = "insert into mphasis.adultinfo values('{}','{}','{}')".format(line[1],line[3],line[6])
                    # step3 : execute query
                    cursor.execute(query)
                    count = count + 1
            # step4 : fetch the details
        else:
            print(filename,"not found")
        print(count," records inserted")
        conn.commit()
        # close the connection
        conn.close()
        
    else:
        print("connection failed")
except Exception as err:
    print(err)