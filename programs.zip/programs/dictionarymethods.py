

book = {'chap1':10 ,"chap2":20 ,"chap3":30}
print("Intial dictionary :",book)
# add new key-value pair
book['chap4'] = 40
book['chap5'] = 50
print(book)

# display individual value
print(book['chap1']) # 10
print(book['chap2']) # 20
#print(book["chap9"]) #

# display keys
print(book.keys())
# display values
print(book.values())
# display key-value items
print(book.items())

print(book['chap9'])
# returns None if key is not existing
print(book.get('chap9')) 

