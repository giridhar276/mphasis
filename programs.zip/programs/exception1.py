
try:
    filename = input('Enter any filename :')
    with open(filename,'r') as fobj:
        for line in fobj:
            print(line.strip())
    output = 9 + 'helo'
except FileNotFoundError as err:
    print(err)
    print("user defined error :","file not found")
except TypeError as err:
    print("Invalid operation")
    print(err)  
except (IndexError,KeyError) as err:
    print(err)
    print("Index or key not found")    
except Exception as err:
    print("some error found",err)
        
        