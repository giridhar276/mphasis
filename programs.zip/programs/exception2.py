import traceback
import sys
try:
    filename = input('Enter any filename :')
    with open(filename,'r') as fobj:
        for line in fobj:
            print(line.strip())
    output = 9 + 'helo'
  
except Exception as err:
    print(" error found",err)
    print("----------------")

    print(sys.exc_info())
    print("----------------")
    traceback.print_exc()
        
    
