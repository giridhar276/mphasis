


try:
    fobj = open("adult.csv","r")
except FileNotFoundError as err:
    print(err)
    print("user defined error :","file not found")
except TypeError as err:
    print("Invalid operation")
    print(err)  
except (IndexError,KeyError) as err:
    print(err)
    print("Index or key not found")    
except Exception as err:
    print("some error found",err)
        
else:
    for line in fobj:
        line = line.strip()
        print(line)
    fobj.close()
finally:
    print("this will be executed all the times")
    