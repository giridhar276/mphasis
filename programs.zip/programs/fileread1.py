# method1
# reading the file line by line
with open('languages.txt','r') as fobj:
    for line in fobj:
        print(line.strip())

#method2
# read the file using fobj.readlines()
with open('languages.txt','r') as fobj:
    print(fobj.readlines()) # reading all the files to the list

#method3
# read the file using fobj.read()
with open('languages.txt','r') as fobj:
    # read the file to the string format
    print(fobj.read())  # ctrl + A    ctrl + c
    
#method4
import csv
with open('languages.txt','r') as fobj:
    # file object to csv understable format
    data = csv.reader(fobj)
    for line in data:
        print(line)
        
        
#method5
import pandas
df = pandas.read_csv('languages.txt')
print(df)

