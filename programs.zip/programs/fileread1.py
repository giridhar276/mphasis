
# reading the file line by line
with open('languages.txt','r') as fobj:
    for line in fobj:
        print(line.strip())
        
# read the file using fobj.readlines()
with open('languages.txt','r') as fobj:
    print(fobj.readlines()) # reading all the files to the list

# read the file using fobj.read()
with open('languages.txt','r') as fobj:
    # read the file to the string format
    print(fobj.read())  # ctrl + A    ctrl + c