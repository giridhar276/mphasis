
# file write operation
# fw acts like cursor or pointer or reference
fw = open("information.csv","w")

fw.write('python' + "\n")
fw.write("java" + "\n")
fw.write("mongodb" + "\n")
fw.close()


fnum = open("numbers.txt","w")
for val in range(1,15):
    fnum.write(str(val) + "\n") #objects should be of same type
fnum.close()

#### if the file is in the different path
#fw = open(r"C:\Users\Administrator\Desktop\info\information.csv","w") # raw string
#fw = open("C:/Users/Administrator/Desktop/info/information.csv","w")
fw = open("C:\\Users\\Administrator\\Desktop\\info\\information.csv","w")

fw.write('python' + "\n")
fw.write("java" + "\n")
fw.write("mongodb" + "\n")
fw.close()



