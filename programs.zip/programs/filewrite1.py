
# file write operation
# fw acts like cursor or pointer or reference
fw = open("information.csv","w")

fw.write('unix' + "\n")
fw.write("java" + "\n")
fw.write("oracl" + "\n")
fw.close()



fnum = open("numbers.txt","w")
for val in range(1,15):
    fnum.write(val + "\n") 
fnum.close()