# regular way # traditional way # legacy way
# method1
fw = open("information1.csv","w")

fw.write('python' + "\n")
fw.write("java" + "\n")
fw.write("mongodb" + "\n")
fw.close()


# pythonic way
# context manager
# if any line starts with keyword with .. we call it context manager
# Advantage: file will be closed automatically when it comes out of indentation
with open("information1.csv","w") as fobj:
    fobj.write('python' + "\n")
    fobj.write("java" + "\n")
    fobj.write("mongodb" + "\n")





    
