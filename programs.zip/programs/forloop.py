# range(start,stop,step)
for val in range(1,11):
    print(val)
    
for val in range(10,0,-1):
    print(val)
    
name = 'python'   ## iterating the string

for char in name:
    print(char)
    
alist = [10,20,30]   ## list
for val in alist:
    print(val)
    
atup = (30,40,50)  # tuple
for val in atup:
    print(val)
    
book = {'chap1':10 , "chap2":20}  # dictionary
for key in book.keys():
    print(key)
    
for value in book.values():
    print(value)
    
for key,value in book.items():
    print(key,value)