#######################
# fixed arguments
##########################
def display(a,b):
    print(a,b)
def display(a,b,c):
    print(a,b,c)    
display(10,20)  # calling function

###############################################
#default arguments  # function overloading
##############################################
def display(a = 0,b= 0,c= 0):
    print(a,b,c)
display(10)
display(10,20)
display(10,20,30)

#####################################
# keyword arguments
#####################################
def display(b,a,c):
    print(a,b,c)
display(a=10,b=20,c=30)

##############################
#variable length arguments
##############################
def display(*args):
    for value in args:
        print(value)

display(10,20,30,40,50,60)