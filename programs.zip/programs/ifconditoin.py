name = 'python programming'
print(name.isupper())
# simple if
if name.isupper():
    print('string is upper')
    print('inside if')
    print("still inside if")
        
# if-else
if name.startswith("py"):
    print("its python programming")
else:
    print("its some other language")
    
# if-elif-elif-elif-elif-else
lang = input('enter any language:')
if lang == 'python':
    print('python')
elif lang == 'java':
    print('java')
elif lang == "oracle":
    print('oracle')
elif lang == 'ruby':
    print('ruby')
else:
    print('its some other language')