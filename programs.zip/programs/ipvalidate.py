
'''
write a program to validate the IP address

Enter any IP address : 192.168.0.1
Its valid IP
Enter any IP address : 1001.1.2.3
Invalid IP
'''
#3.3.3.3 

ip = input('Enter any IP :')
data = ip.split(".")
if int(data[0]) in range(1,255) and int(data[1]) in range(0,255) and int(data[2]) in range(0,255) and int(data[1]) in range(0,255) :
   if ip.count(".") == 3:
       print("valid IP")
else:
    print("Invalid IP")
    
    
    
import ipaddress
ip = '1920.3.3.3'
ipobj = ipaddress.ip_address(ip)
if ipobj:
    print("Valid IP")
else:
    print("invalid ip")
