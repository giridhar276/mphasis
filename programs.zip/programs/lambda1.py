# every process contains set of system calls
# regular way
def display(a,b):
    c = a + b
    return c

total = display(10,20) 
print(total)


# pythonic way
# lambda function
# lambda is the replacement of single liner function
# syntax
# advantage: lambda expression will be replaced in the function body
# functioname = lambda variables: expression

display = lambda x,y: x + y
total = display(10,20) 
print(total)




display = lambda x,y: x if x > 5 else y
total = display(10,20) 
print(total)



display = lambda *args: sum(args)
total = display(10,20,30,40,50,60,70,80,90,100) 
print(total)


display = lambda *args: max(args)
total = display(10,20,30,40,50,60,70,80,90,100) 
print(total)


def display(*args):
    for val in args:
        if val > 50:
            print(val)
display(10,20,30,40,50,60,70,80,90,100) 



alist = ["google","unix","java"]
#output
#["www.google.com","www.unix.com","www.java.com"]


# method1
blist = []
for item in alist:
    blist.append("www." + item + ".com")
print(blist)    


# method2
# map( function,iterable)
append = lambda x: "www." + x + ".com"
print(list(map(append,alist)))


#method3
print(list(map(lambda x: "www." + x + ".com",alist)))





















