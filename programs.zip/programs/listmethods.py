alist = [10,56,23,21,56,67,43,87]
# list slicing
print(alist)
print(alist[0:5])
################# methods ################
# list.append(value)  - add single value
alist.append(80)
print('After appending :',alist)
# list.extend(list) - multiple values
alist.extend([48,30,21])
print('After extending :',alist)
# list.insert(index,value)
alist.insert(1,60)
print('After inserting ;',alist)
#list.pop()
alist.pop(2)  # 2 is the index  # value at index will be removed
print('AFter pop:',alist)
#list.remove(value)  # value will be removed
alist.remove(56)  # 56 will be removed
# list.reverse()
alist.reverse()
print('After reversing :', alist)


#list[start:stop:incremental]
alist = [10,56,23,21,56,67,43,87]
alist[5:1:-1]



alist = [10,10,10,10,10,56,23,21,56,67,43,87]
print(alist.count(10))
alist.remove(10)
print(alist)
for val in range(0,alist.count(10)):
    alist.remove(10)
print("after removing :",alist)


