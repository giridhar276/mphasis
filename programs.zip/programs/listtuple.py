########## differnece between list and tuple #######

#list
alist = [10,20,30]
alist[0] = 100
print(alist)


# immutable
atup = (30,0,40)
atup[0] = 3000
print(atup)

# type casting - converting from one object to another object
alist = list(atup)  # converting to list
alist.append(50)
alist[0] = 3000   # make required changes
atup = tuple(alist) # reconverting back to tuple
print(atup)          # display


