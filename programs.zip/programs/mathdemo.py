
## method1 :importing all the methods
import math
print(math.floor(2.3))
print(math.tan(1))
print(math.cos(2))

## method2 : importing allt he methods with alias
import math as m
print(m.floor(2.3))
print(m.tan(1))
print(m.cos(2))


# method3 : importing required methods only
#  . is not required here
from math import cos,sin,floor
print(cos(1))
print(sin(2))
print(floor(34.2))


