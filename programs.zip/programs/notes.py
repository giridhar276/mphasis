from Sivaraman S to everyone:    9:27 PM
https://seveas.github.io/python-hpilo/
https://hewlettpackard.github.io/python-ilorest-library/
https://pypi.org/project/IdracRedfishSupport/
from Sivaraman S to everyone:    9:30 PM
https://github.com/lenovo/python-redfish-lenovo
Python (PyLXCA) toolkit
from Sivaraman S to everyone:    9:31 PM
https://github.com/lenovo/pylxca