

## requets.get()
import requests

url = "https://api.uber.com"

endpoint = "/products"


response = requests.get(url + endpoint , auth= (username,password))   


# requests.delete()
import requests
url = "https://api.uber.com"
endpoint = "/requests/afdafd"
response = requests.delete(url +endpoint , auth=())


#
import requests
url = "https://api.uber.com"
endpoint = "/estimates/price"
response = requests.get(url +endpoint , auth=())
