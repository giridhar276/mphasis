################### this website returns html content ###############
import requests  # to connect to the http web
from bs4 import BeautifulSoup  # to read html

url = "https://www.github.com/"
response = requests.get(url)
print("Status code ;",response.status_code)
if response.status_code == 200 :
    print("successful")
else:
    print("unable to open the website")
soup = BeautifulSoup(response.text, 'html.parser')    
for link in soup.find_all('a'):
    print(link.get('href'))
    print("--------")
    


############# this website returns json content
import requests  # to connect to the http web
import json      # to read json 
url = "https://api.github.com/"
response = requests.get(url)
print("Status code ;",response.status_code)
print(type(response.text))  # string
# converting string to the dictionary
data = json.loads(response.text)
for key,value in data.items():
    print(key.ljust(20),value)

    

    
    
    