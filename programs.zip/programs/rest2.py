import requests
import json
try:
        
    url = "https://api.github.com"
    
    endpoint = "/user"
    
    username = "giridhar276"  # your username
    
    # your token
    token = "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"
    
    finalurl = url + endpoint
    
    response = requests.get(finalurl,auth=(username,token))
    
    data = json.loads(response.text)
    
    for key,value in data.items():
        print(key.ljust(20), ":",value)

except Exception as err:
    print(err)