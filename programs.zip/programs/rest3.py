import requests  # to connect to the http web
import json
try:
    
    url = "https://api.github.com"
#    endpoint = "/user"
    endpoint = "/gists"

    username = "giridhar276"
    password = "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"
    finalurl = url + endpoint

    print("checking ", url ,"using user :", username) 
    
    local_file = "adult.csv"
    with open(local_file) as fh:
        mydata = fh.read()
    
    payload = {
        "description": "rest-api - DK testing" ,
        "public" : "true" ,
        "user" : username ,
        "files" : {
        local_file : { 
        "content" : mydata}
        }
        }
    
    r1 = requests.post(finalurl, data = json.dumps(payload), auth = (username, password))
    print(r1.json())
    #response = requests.get(finalurl,auth=(username,token))
    #data = json.loads(response.text)
    #print(data)
    #for item in data:
    #    for key,value in item.items():
    #        print(key.ljust(20),":", value)
    #print("Status code ;",response.status_code)
#    for key, value in data.items():
#     print(key.ljust(20), ":", value)
    
except Exception as err:
    print(err)
    
    
    
############ rest program

1. find the url
2. method ( get post put delete)
3. endpoint