import os   
import requests
import json
from requests.auth import HTTPBasicAuth
server = "https://api.github.com"
url = server + "/gists"
user = "giridhar276"
print("checking ", url, "using user:", user)



files = {
    "description": "lab examples",
    "public": "true",
    "user" : user,
    "files" : {}
}
for file in os.listdir():
    with open(file) as fobj:
        content = fobj.read()     
        files["files"].update({file :{ "content":content}})
r1 = requests.post(url, data=json.dumps(files), auth=user,'9ef89321ec1f8188c4b45fbc67db836da8ede3cf')
print(r1.json())
