 
  
import requests
import json


server = "https://api.github.com"

endpoint = "/users/giridhar276/repos"

final = server + endpoint

r = requests.get(final, auth=('giridhar276','c0178804d8d5de1ab2c0068967fb6e57fbde7c0c'))

# r.text ------------> json format
# reading data from server and converting to dictionary from json


 