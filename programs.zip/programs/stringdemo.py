

print(10,20,30)

val = 10.45
print("value is",val)

print("unix","java","ruby","hadoop")

name = "python"
print("I love", name)

# this is single line comment


'''
this is the 
commented line

'''