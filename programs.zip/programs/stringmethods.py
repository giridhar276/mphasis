
# string
# slicing = extracting part of the string

# string[start:stop:incremental]
name = 'python programming'
print(name[0]) # p
print(name[1])# y
print(name[0:3])
print(name[9:14])
print(name[:])  # python programming
print(name[0:6:1])
print(name[1:9:1])
print(name[2:18:2])
print(name[::]) 
print(name[-1])    # g
print(name[-4:-1])      
print(name[-8:-2])


val = 10


name = 'python programming'

print(name.capitalize())
print(name.title())
print(name.upper())
print(name.lower())

print(name.isupper())
print(name.islower())

print(name.startswith("py"))
print(name.startswith("z"))

print(name.endswith("g"))

print(name.split(" "))

print(name.replace("python","java"))
print(name)
# to make the changes permanent
#name = name.replace("python","java")

























