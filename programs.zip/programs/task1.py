

'''
write a program to read filename with extension from the keyboard and display the filename and extension separetely.

sample output:
Enter any filename :  hello.py
Filname  : hello
extension: py

'''



filename = input("Enter any filename with extension :")

if "." in filename  and filename.count(".")  == 1:
    data = filename.split(".")
    print("filname :",data[0])
    print("extnsion :",data[1])
else:
    print("invalid filename")

