
'''
book = {"chap1":[10,'UK','Mark'] ,"chap2":[20,'US','Pet']}

write a program to add '200pages' to the list of chap1  and
                       '400pages' to the list of chap2
                       
'''



book = {"chap1":[10,'UK','Mark'] ,"chap2":[20,'US','Pet']}

book['chap1'].append('200pages')
book['chap2'].append('400pages')

print(book)


# method2
book['chap1'].insert(3,'200pages')
book['chap2'].insert(3,'400pages')
print(book)