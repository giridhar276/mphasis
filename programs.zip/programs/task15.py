

'''
write a program to display all distinct workclasses

Output:
State-gov
Private
Self-emp-not-inc
Federal-gov
..
'''

import csv
workclass = set()
with open('adult.csv','r') as fobj:
    data = csv.reader(fobj)
    # processing
    for line in data:
        workclass.add(line[1])
    # display output
    for item in workclass:
        print(item.strip())
    