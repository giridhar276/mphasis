'''
write a program to display the below output :

Total Male count : xxxx
Total female count : xx
'''


import csv
malecount = 0
femalecount = 0
with open('adult.csv','r') as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        gender = line[9].strip()
        if gender == 'Male':
            malecount+=1
        elif gender == 'Female':
            femalecount+=1

print("Total male count :",malecount)
print('Total female count :',femalecount)
        