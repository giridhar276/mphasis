

#write a program to read the adult.csv and  display all the lines in the lower case

with open('adult.csv','r') as fobj:
    for line in fobj:
        print(line.strip().lower())
