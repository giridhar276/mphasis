'''

write a program to read the adult.csv and display 
all the lines in the lower case and write the output to backup.csv
'''

# read operation
with open('adult.csv') as fr:
    with open('backup.csv','w') as fw:
        for line in fr:
            fw.write(line)
