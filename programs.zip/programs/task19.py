
#write a program to read the adult.csv and replace all the lines 
# containing United-States TO USA and display the output.



with open("adult.csv", "r") as obh:
    for line in obh:
        print(line.replace(' United-States','USA'))
        