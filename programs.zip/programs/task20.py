


#write a program to display ONLY .py files line by line

import os

try:
    files  = os.listdir()
    
    for file in files:
        if file.endswith(".py"):
            print(file)
except Exception as err:
    print(err)