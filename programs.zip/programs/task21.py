

#write a program to delete .csv files from the current directory

import os

try:
    files  = os.listdir()
    
    for file in files:
        if file.endswith(".csv"):
            os.remove(file)
            print(file,"deleted successfully")
except Exception as err:
    print(err)