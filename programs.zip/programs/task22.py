


import os

try:
    for val in range(1,101):
        dirname = "dir" + str(val)
        os.mkdir(dirname)
except Exception as err:
    print(err)