


import os

try:
    for val in range(1,101):
        dirname = "dir" + str(val)
        if os.path.exists(dirname):
            os.rmdir(dirname)
            print(dirname,"deleted")
except Exception as err:
    print(err)