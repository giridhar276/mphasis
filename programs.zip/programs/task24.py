
'''
write a program to display all the files and its size

file1.py   100 bytes
file2.py    34 bytes
'''


import os

try:
    for file in os.listdir():
        print(file.ljust(15),os.path.getsize(file),"bytes")
except Exception as err:
    print(err)