


import sys
import os
import shutil


try:
    source = 'C:\\Users\\Administrator\\Desktop\\source\\'
    destination = 'C:\\Users\\Administrator\\Desktop\\destination'
    for file in os.listdir(source):
        if os.path.exists(source + file):
            shutil.copy(source +file, destination)
except Exception as err:
    print(err)
        
    
    
    
#shutil.copy('C:\\Users\\Administrator\\Desktop\\source\\fileread1.py",destination    )
            
            
            
