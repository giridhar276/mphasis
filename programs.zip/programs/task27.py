
'''
write a program to display all the files and directories separately as below

Files
-----
file1
file2
file3


directories
------------
dir1
dir2	
'''


import os

files = []
dirs = []

for file in os.listdir():
    if os.path.isfile(file):
        files.append(file)
    elif os.path.isdir(file):
        dirs.append(file)
        
## display all the files
for file in files:
    print(file)
    
print("---------------")
# display dirs
for adir in dirs:
    print(adir)