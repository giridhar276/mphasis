'''
write a program to display the below statistics

-CPU Percentage
-virtual memory information
-swap memory information
-disk partitions information
-C:\ usage
'''

import psutil
try:
    print("CPU percentage :", psutil.cpu_percent())
    print("-------------------------------------------")
    print("virutal memory :", psutil.virtual_memory())
    print("-------------------------------------------")
    print("swap memory :",psutil.swap_memory())
    print("-------------------------------------------")
    print("disk partitions :",psutil.disk_partitions())
    print("-------------------------------------------")
    print("C: usage :",psutil.disk_usage("C:\\"))
    print("-------------------------------------------")
except Exception as err:
    print(err)