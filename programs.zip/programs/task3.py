
'''
capture any string from the keyboard and perform the below operations

1. check whether the string is upper or not
2. convert the string to list
3. display the string exactly in the center of 30 spaces width
4. convert the string into lower case
'''

string = input('Enter any string :')

#1
if string.isupper():
    print("String is defined in upper")
else:
    print('lower case')
    
#2
data = list(string)
print(data)

for item in string:
    print(item)


#3
print(string.center(30))


#4
strlwr = string.lower()
print(strlwr)