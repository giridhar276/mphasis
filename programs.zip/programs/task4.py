'''
write a progam to capture filename from the keyboard and display the type of the file
if the filename is ending with .py  .... display "Its python file"
if the filename is ending with .pl   .... display "Its perl file"
If the filename is ending with .c  ....... display "Its C lang file"
if the filename is ending with .json ...  display "Its json file"

Enter any filename :  info.py
Python file

'''

name = input('Enter any filename :')
if name.endswith(".py"):
    print('python file')
elif name.endswith(".pl"):
    print('perl file')
elif name.endswith(".c"):
    print("c file")
elif name.endswith(".json"):
    print("json file")
else:
    print("wrong input")
    
    
    
first = int(input('Enter first value :'))
seccond = int(input("enter second value :"))


values = input("Enter values :")
data = values.split(",")
print(data)





