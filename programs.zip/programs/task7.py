
'''
define some list as below

alist = ["google","oracle","microsoft"]

write a program to
add "http://www"  at the beginning and  
add ".com" at tht end of the string
'''

# method1
alist = ["google","oracle","microsoft"]

for item in alist:
    domain = "http://www." + item + ".com"
    print(domain)
    
# method2
#string
domain = "https://www.{}.com"
for item in alist:
    print(domain.format(item))
    
    
