
name = 'python programming'
print(name.isupper())

# simple if
if name.isupper():
    print('string is upper')
    
    
# if-else
if name.startswith("py"):
    print("its python programming")
else:
    print("its some other language")
    
# if-elif-elif-elif-elif-else