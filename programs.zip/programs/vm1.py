
from pyVim import connect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification (not recommended for production)
#ssl._create_default_https_context = ssl._create_default_https_context_factory

def connect_to_vcenter(host, username, password):
    try:
        service_instance = connect.SmartConnect(
            host=host,
            user=username,
            pwd=password
        )
        return service_instance
    except Exception as e:
        print("Error connecting to vCenter:", e)
        return None

def disconnect_from_vcenter(service_instance):
    if service_instance:
        connect.Disconnect(service_instance)

def main():

    vcenter_host = "192.168.20.60"
    vcenter_username = "administrator@vsphere.local"
    vcenter_password = "Class@100"

    # Connect to vCenter
    service_instance = connect_to_vcenter(vcenter_host, vcenter_username, vcenter_password)
    if not service_instance:
        return

    # Perform operations here
    # For example, list VMs
    content = service_instance.RetrieveContent()
    vm_view = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    vms = vm_view.view

    print("List of VMs:")
    for vm in vms:
        print(vm.name)

    # Disconnect from vCenter
    disconnect_from_vcenter(service_instance)

if __name__ == "__main__":
    main()
