


from pyVim.connect import SmartConnect
import urllib3.contrib.pyopenssl

#urllib3.contrib.pyopenssl.inject_into_urllib3()

c = SmartConnect(host="172.16.0.129", user="administrator@vsphere.local", pwd='Nte#2567',port=443)

print(c.CurrentTime())
