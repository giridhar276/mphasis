#to check for vm worttion is aacessbl or not


from pyVim.connect import SmartConnect
import urllib3.contrib.pyopenssl

#urllib3.contrib.pyopenssl.inject_into_urllib3()

c = SmartConnect(host="192.168.20.60", user="administrator@vsphere.local", pwd="Class@100",port=443)

print(c.CurrentTime())
