from pyVim import connect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification (not recommended for production)
#ssl._create_default_https_context = ssl._create_default_https_context_factory

def connect_to_vcenter(host, username, password):
    try:
        service_instance = connect.SmartConnect(
            host=host,
            user=username,
            pwd=password
        )
        return service_instance
    except Exception as e:
        print("Error connecting to vCenter:", e)
        return None

def disconnect_from_vcenter(service_instance):
    if service_instance:
        connect.Disconnect(service_instance)

def list_all_vms(service_instance):
    if not service_instance:
        return

    content = service_instance.RetrieveContent()
    vm_view = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    vms = vm_view.view

    print("List of VMs:")
    for vm in vms:
        print(vm.name)

def main():
    vcenter_host = '172.16.0.129'
    vcenter_username ='administrator@vsphere.local'
    vcenter_password = 'Nte#2567'

    # Connect to vCenter
    service_instance = connect_to_vcenter(vcenter_host, vcenter_username, vcenter_password)
    if not service_instance:
        return

    # List all VMs
    list_all_vms(service_instance)

    # Disconnect from vCenter
    disconnect_from_vcenter(service_instance)

if __name__ == "__main__":
    main()
