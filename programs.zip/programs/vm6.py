from pyVim import connect
from pyVmomi import vim

# Define the connection parameters


vcenter_server = '172.16.0.129'
username ='administrator@vsphere.local'
password = 'Nte#2567'

# Connect to the vCenter server
si = connect.SmartConnect(host=vcenter_server, user=username, pwd=password)

# Create a view of VM objects
container = si.content.viewManager.CreateContainerView(
    si.content.rootFolder, [vim.VirtualMachine], True
)

# Iterate through the VMs and display their information
for vm in container.view:
    print("VM Name:", vm.name)
    print("VM Power State:", vm.runtime.powerState)
    print("VM CPU Count:", vm.config.hardware.numCPU)
    print("VM Memory Size (MB):", vm.config.hardware.memoryMB)
    print("VM Guest OS:", vm.config.guestFullName)
    print("\n")

# Disconnect from the vCenter server
connect.Disconnect(si)
