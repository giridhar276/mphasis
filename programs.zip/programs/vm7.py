#pyvmomi  to authenticate and print


from pyVim import connect

# Define the connection parameters
#vcenter_server = '172.16.0.129'
#username ='administrator@vsphere.local'
#password = 'Nte#2567'


vcenter_server = "192.168.20.60"
username = "administrator@vsphere.local"
password = "Class@100"


try:
    # Connect to the vCenter server
    si = connect.SmartConnect(host=vcenter_server, user=username, pwd=password)
    
    if si:
        print("Authentication successful!")
        print("You're doing a great job managing your virtual infrastructure!")
        
        # Disconnect from the vCenter server
        connect.Disconnect(si)
    else:
        print("Authentication failed. Please check your credentials.")
except Exception as e:
    print("An error occurred while connecting to vCenter:", str(e))

