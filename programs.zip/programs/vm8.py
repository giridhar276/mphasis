from pyVim import connect
from pyVmomi import vim

# Define the connection parameters

vm_name_to_power_on = 'your_vm_name'

vcenter_server = '172.16.0.129'
username ='administrator@vsphere.local'
password = 'Nte#2567'


def power_on_vm(vm):
    try:
        if vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOff:
            print(f"Powering on VM: {vm.name}")
            task = vm.PowerOn()
            task_result = task.wait()
            if task_result == vim.TaskInfo.State.success:
                print(f"VM {vm.name} has been powered on.")
            else:
                print(f"Failed to power on VM {vm.name}.")
        else:
            print(f"VM {vm.name} is already powered on.")
    except Exception as e:
        print(f"An error occurred while powering on VM {vm.name}: {str(e)}")

try:
    # Connect to the vCenter server
    si = connect.SmartConnect(host=vcenter_server, user=username, pwd=password)

    if si:
        print("Connected to vCenter server.")

        # Search for the VM by name
        content = si.content
        vm_folder = content.rootFolder
        vm_view = content.viewManager.CreateContainerView(vm_folder, [vim.VirtualMachine], True)
        
        for vm in vm_view.view:
            if vm.name == vm_name_to_power_on:
                power_on_vm(vm)
                break
        else:
            print(f"VM {vm_name_to_power_on} not found.")

        # Disconnect from the vCenter server
        connect.Disconnect(si)
    else:
        print("Authentication failed. Please check your credentials.")
except Exception as e:
    print("An error occurred:", str(e))
