from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import atexit
import sys
import time

def connect_to_vcenter(host, user, password):
    try:
        service_instance = SmartConnect(host=host, user=user, pwd=password, port=443)
        atexit.register(Disconnect, service_instance)
        return service_instance.RetrieveContent()
    except Exception as e:
        print(f"Error connecting to vCenter: {str(e)}")
        sys.exit(1)

def wait_for_task(task):
    '''
    This function takes a task object as a parameter and waits for the task to complete.
    It periodically checks the task's state and sleeps for 1 second between checks.
    When the task completes (either successfully or with an error), 
    it returns the task's result or None, respectively.
    '''
    
    while task.info.state in [vim.TaskInfo.State.queued, vim.TaskInfo.State.running]:
        time.sleep(1)

    if task.info.state == vim.TaskInfo.State.success:
        return task.info.result
    elif task.info.state == vim.TaskInfo.State.error:
        print(f"Task failed: {task.info.error.msg}")
        return None

def power_on_vm(vm):
    '''
    This function takes a VM object (vm) as a parameter and attempts to power it on.
    It first checks if the VM is already powered on. If not, it initiates a power-on task for the VM.
    It uses the wait_for_task function to wait for the task to complete and prints appropriate messages based on the outcome.
    '''
    try:
        if vm.runtime.powerState != vim.VirtualMachinePowerState.poweredOn:
            task = vm.PowerOn()
            result = wait_for_task(task)
            if result:
                print(f"VM '{vm.name}' powered on successfully.")
            else:
                print(f"Failed to power on VM '{vm.name}'.")
        else:
            print(f"VM '{vm.name}' is already powered on.")
    except Exception as e:
        print(f"Error powering on VM '{vm.name}': {str(e)}")

def main():
    # Edit these with your vCenter/ESXi server credentials

    vcenter_host = "192.168.20.60"
    vcenter_user = "administrator@vsphere.local"
    vcenter_password = "Class@100"

    # Connect to vCenter server
    '''
    This function takes three parameters: host, user, and password, representing the vCenter server details.
    It attempts to connect to the vCenter server using the provided credentials.
    If the connection is successful, it registers a callback to disconnect when the script exits and 
    returns the content (vCenter server's inventory) object.
                                                                                                                          If an exception occurs during the connection attempt, it prints an error message and exits the script.
    '''
    content = connect_to_vcenter(vcenter_host, vcenter_user, vcenter_password)

    # Specify the name(s) of the VM(s) you want to power on
    vm_names_to_power_on = ["centos", "win10"]

    # Retrieve all VMs and attempt to power on the specified ones
    try:
        container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
        vms = container.view
        for vm in vms:
            if vm.name in vm_names_to_power_on:
                power_on_vm(vm)
    except Exception as e:
        print(f"Error retrieving VMs: {str(e)}")

if __name__ == "__main__":
    main()
