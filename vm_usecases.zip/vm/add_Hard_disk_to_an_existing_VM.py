#To add a hard disk to an existing VM using the pyvmomi library in Python, you'll need to connect to your VMware vCenter or ESXi host, locate the VM, and then add a new virtual disk to it. 

from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim

# Define your vCenter/ESXi server connection parameters
vc_host = "192.168.20.60"
vc_port = 443
vc_user = "administrator@vsphere.local"
vc_password = "Class@100"

# VM name and size of the new hard disk (in GB)
vm_name = 'win10'
disk_size_gb = 1  # Adjust as needed

def add_hard_disk_to_vm():
    try:
        # Connect to the vCenter/ESXi server
        service_instance = SmartConnect(host=vc_host, port=vc_port, user=vc_user, pwd=vc_password)
        
        # Retrieve the content of the service instance
        content = service_instance.RetrieveContent()
        
        # Search for the VM by name
        vm = None
        for child in content.rootFolder.childEntity:
            if hasattr(child, 'vmFolder'):
                vm_folder = child.vmFolder
                vm_list = vm_folder.childEntity
                for virtual_machine in vm_list:
                    if virtual_machine.name == vm_name:
                        vm = virtual_machine
                        break
        
        if vm is None:
            print(f"VM with name '{vm_name}' not found.")
            return
        
        # Create a new virtual disk specification
        disk_spec = vim.vm.device.VirtualDeviceSpec()
        disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
        disk_spec.device = vim.vm.device.VirtualDisk()
        disk_spec.device.backing = vim.vm.device.VirtualDisk.FlatVer2BackingInfo()
        disk_spec.device.backing.thinProvisioned = True
        disk_spec.device.backing.diskMode = 'persistent'
        disk_spec.device.unitNumber = 0
        disk_spec.device.capacityInKB = disk_size_gb * 1024 * 1024
        
        # Add the new virtual disk to the VM
        config_spec = vim.vm.ConfigSpec(deviceChange=[disk_spec])
        task = vm.ReconfigVM_Task(config_spec)
        
        # Wait for the task to complete
        task_info = task.info
        while task_info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
            task_info = task.info
        
        if task_info.state == vim.TaskInfo.State.success:
            print(f"Successfully added {disk_size_gb} GB hard disk to '{vm_name}'.")
        else:
            print(f"Failed to add hard disk to '{vm_name}': {task_info.error.msg}")
    
    except Exception as e:
        print(f"An error occurred: {str(e)}")
    finally:
        Disconnect(service_instance)

# Call the function to add the hard disk to the VM
add_hard_disk_to_vm()
