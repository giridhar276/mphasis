# -*- coding: utf-8 -*-
"""
Created on Thu Sep  7 01:52:34 2023

@author: Administrator
"""

from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"



# Virtual machine configuration
vm_name = "centos"
datastore_name = "datastore"  # Replace with your datastore name
vm_folder_name = "vm"     # Replace with your desired folder name
cluster_name = None            # Replace with your cluster name
resource_pool_name = "Resources"  # Replace with your resource pool name

template_name = None   # Replace with the name of the VM template to clone from


# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to create a virtual machine from scratch
def create_vm_from_scratch():
    content = service_instance.RetrieveContent()

    # Find the VM folder
    folder = None
    for datacenter in content.rootFolder.childEntity:
        if isinstance(datacenter, vim.Datacenter):
            if vm_folder_name in [f.name for f in datacenter.vmFolder.childEntity]:
                folder = [f for f in datacenter.vmFolder.childEntity if f.name == vm_folder_name][0]
                break

    if folder is None:
        print(f"Folder '{vm_folder_name}' not found.")
        return

    # Specify the virtual machine configuration
    vm_config = vim.vm.ConfigSpec()
    vm_config.name = vm_name
    vm_config.memoryMB = 1024  # Memory in MB
    vm_config.numCPUs = 2      # Number of CPUs

    # Create a virtual machine
    try:
        task = folder.CreateVM(vm_config, None, None)
        WaitForTask(task)
        print(f"Virtual machine '{vm_name}' created successfully.")
    except Exception as e:
        print(f"Error: {str(e)}")

# Function to wait for a vCenter task to complete
def WaitForTask(task):
    while task.info.state == vim.TaskInfo.State.running:
        pass
    if task.info.state == vim.TaskInfo.State.success:
        return task.info.result
    else:
        print(f"Task failed: {task.info.error.msg}")
        return None

# Call the function to create the VM from scratch
create_vm_from_scratch()

# Disconnect from the vCenter Server
Disconnect(service_instance)
