from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification (use only for testing, not recommended for production)
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Virtual machine configuration
vm_name = "MyNewVM"
datastore_name = "datastore"  # Replace with your datastore name
datacenter_name = "Datacenter"  # Replace with your datacenter name
resource_pool_name = "Resources"  # Replace with your resource pool name

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to create a virtual machine from scratch
def create_vm_from_scratch():
    content = service_instance.RetrieveContent()

    # Find the datacenter where you want to create the VM
    datacenter = None
    for entity in content.rootFolder.childEntity:
        if isinstance(entity, vim.Datacenter) and entity.name == datacenter_name:
            datacenter = entity
            break

    if not datacenter:
        print(f"Datacenter '{datacenter_name}' not found.")
        return

    # Find the resource pool where you want to place the VM
    resource_pool = None
    for rp in datacenter.hostFolder.childEntity:
        if isinstance(rp, vim.ResourcePool) and rp.name == resource_pool_name:
            resource_pool = rp
            break

    if not resource_pool:
        print(f"Resource pool '{resource_pool_name}' not found.")
        return

    # Specify the virtual machine configuration
    vm_config = vim.vm.ConfigSpec()
    vm_config.name = vm_name
    vm_config.memoryMB = 1024  # Memory in MB
    vm_config.numCPUs = 2      # Number of CPUs

    # Create a virtual machine
    try:
        vm_folder = datacenter.vmFolder
        task = vm_folder.CreateVM_Task(config=vm_config, pool=resource_pool)
        WaitForTask(task)
        print(f"Virtual machine '{vm_name}' created successfully.")
    except Exception as e:
        print(f"Error: {str(e)}")

# Function to wait for a vCenter task to complete
def WaitForTask(task):
    while task.info.state == vim.TaskInfo.State.running:
        pass
    if task.info.state == vim.TaskInfo.State.success:
        return task.info.result
    else:
        print(f"Task failed: {task.info.error.msg}")
        return None

# Call the function to create the VM from scratch
create_vm_from_scratch()

# Disconnect from the vCenter Server
Disconnect(service_instance)
