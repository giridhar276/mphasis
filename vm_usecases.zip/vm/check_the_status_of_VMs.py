from pyVim import connect
from pyVmomi import vim
import ssl
import time
import datetime
currentime = time.strftime("%H:%M:%S")
print(currentime)

def get_all_vm_statuses(vcenter_host, vcenter_user, vcenter_password):
    try:
        # Connect to the vCenter server
        si = connect.SmartConnect(host=vcenter_host,
                                  user=vcenter_user,
                                  pwd=vcenter_password,
                                  )

        # Retrieve the content of the vCenter server
        content = si.RetrieveContent()

        # Retrieve all virtual machines
        vm_folder = content.rootFolder
        vm_view = content.viewManager.CreateContainerView(vm_folder, [vim.VirtualMachine], True)

        vm_statuses = {}  # Dictionary to store VM name and status

        for vm in vm_view.view:
            vm_name = vm.summary.config.name
            power_state = vm.summary.runtime.powerState
            if power_state == vim.VirtualMachinePowerState.poweredOn:
                vm_status = 'Running'
            elif power_state == vim.VirtualMachinePowerState.poweredOff:
                vm_status = 'Shutdown'
            elif power_state == vim.VirtualMachinePowerState.suspended:
                vm_status = 'Suspended'
            else:
                vm_status = 'Unknown'
            
            vm_statuses[vm_name] = vm_status
            # dictionary[key] = value
        
        # Close the view
        vm_view.Destroy()

        # Disconnect from the vCenter server
        connect.Disconnect(si)

        return vm_statuses

    except Exception as e:
        print(f"An error occurred: {str(e)}")

def write_vm_status(vm_statuses,output_file):
    with open("C:\\Users\\Administrator\\Desktop\\" + output_file,"w") as file:
        file.write("VM name" +"," + "status" + "," + "Execution time" + "\n")
        for vm_name,status in vm_statuses.items():
            file.write(vm_name + "," + status + "," + currentime + "\n")
        

if __name__ == "__main__":
    filename = time.strftime("vmstatus_%d_%m_%Y.csv")
    vcenter_host = "192.168.20.60"
    vcenter_user = "administrator@vsphere.local"
    vcenter_password = "Class@100"

    vm_statuses = get_all_vm_statuses(vcenter_host, vcenter_user, vcenter_password)
    for vm_name, status in vm_statuses.items():
        
        print(f"VM '{vm_name}' is {status}")
        #print("VM '{}' is {}".format(vm_name,status))
        
    write_vm_status(vm_statuses,filename)        
