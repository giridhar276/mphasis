from pyVim import connect


import ssl

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    # Legacy Python that doesn't verify HTTPS certificates by default
    pass
else:
     # Handle target environment that doesn't support HTTPS verification
    ssl._create_default_https_context = _create_unverified_https_context


# Define your vCenter or ESXi server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


try:
    # Connect to the vCenter or ESXi server
    service_instance = connect.SmartConnect(
        host=vcenter_host,
        user=vcenter_user,
        pwd=vcenter_password
    )

    # Successfully connected, print an encouragement message
    print("Welcome to the VMware community! We're glad you're here.")
    # Disconnect from the vCenter or ESXi server
    connect.Disconnect(service_instance)
except Exception as e:
    # Handle any authentication or connection errors
    print(f"Error connecting to VMware: {str(e)}")

