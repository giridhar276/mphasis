from pyVim import connect
from pyVmomi import vim
import atexit

def create_vm(vcenter_ip, username, password, vm_name, datacenter_name, cluster_name, datastore_name, 
              vm_template_name=None, host_name=None):
    try:
        # Connect to the vCenter server
        service_instance = connect.SmartConnect(host=vcenter_ip, user=username, pwd=password)
        atexit.register(connect.Disconnect, service_instance)

        # Find the datacenter, cluster, datastore, host, and template objects
        content = service_instance.RetrieveContent()
        datacenter = content.rootFolder.childEntity[0]
        cluster = [c for c in datacenter.hostFolder.childEntity if isinstance(c, vim.ClusterComputeResource) and c.name == cluster_name][0]
        datastore = [d for d in datacenter.datastoreFolder.childEntity if isinstance(d, vim.Datastore) and d.name == datastore_name][0]

        if vm_template_name:
            template = [vm for vm in datacenter.vmFolder.childEntity if isinstance(vm, vim.VirtualMachine) and vm.name == vm_template_name][0]
        else:
            template = None

        # Create VM configuration
        vm_folder = datacenter.vmFolder
        vmx_file = vim.vm.FileInfo(logDirectory=None, snapshotDirectory=None, suspendDirectory=None, vmPathName=None)
        config = vim.vm.ConfigSpec(name=vm_name, memoryMB=512, numCPUs=1, files=vmx_file, guestId="centos")
        device_config = []

        # Clone the VM from a template or create a new VM
        if template:
            clone_spec = vim.vm.CloneSpec(location=vim.vm.RelocateSpec(datastore=datastore),
                                          powerOn=True, template=False, config=config, deviceChange=device_config)
            task = template.Clone(folder=vm_folder, name=vm_name, spec=clone_spec)
        else:
            task = vm_folder.CreateVM(name=vm_name, config=config, pool=cluster.resourcePool, host=host_name)

        # Wait for the VM creation task to complete
        while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
            pass

        if task.info.state == vim.TaskInfo.State.success:
            print(f"VM '{vm_name}' created successfully.")
        else:
            print(f"VM creation failed with task state: {task.info.state}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    vcenter_ip = "192.168.20.60"
    username = "administrator@vsphere.local"
    password = "Class@100"
    vm_name = "centos"
    datacenter_name = "Datacenter"
    cluster_name = "Cluster"
    datastore_name = "Datastore"
    vm_template_name = "MyTemplate"  # Set to None if you want to create a new VM
    host_name = "ESXiHost"  # Optional host name, set to None to let vCenter choose

    create_vm(vcenter_ip, username, password, vm_name, datacenter_name, cluster_name, datastore_name,
              vm_template_name, host_name)




'''
Replace the placeholders your_vcenter_ip, your_username, and your_password with your vCenter server information. Customize the VM configuration by modifying the config object as needed. This script also provides options to clone from a template and specify a host (ESXi host) for the VM if desired.

'''