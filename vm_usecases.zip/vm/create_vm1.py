from pyVim import connect
from pyVmomi import vim
import ssl

def create_vm(vm_name, template_name, datastore_name, cluster_name, host_name, vcenter_host, vcenter_user, vcenter_password):
    try:

        # Connect to the vCenter server
        si = connect.SmartConnect(host=vcenter_host,
                                  user=vcenter_user,
                                  pwd=vcenter_password)

        # Find the datacenter (assuming there's only one)
        datacenter = si.content.rootFolder.childEntity[0]

        # Find the datastore by name
        datastore = None
        for ds in datacenter.datastoreFolder.childEntity:
            if ds.name == datastore_name:
                datastore = ds
                break

        if not datastore:
            print(f"Datastore '{datastore_name}' not found.")
            return

        # Find the cluster by name
        cluster = None
        for cl in datacenter.hostFolder.childEntity:
            if cl.name == cluster_name:
                cluster = cl
                break

        if not cluster:
            print(f"Cluster '{cluster_name}' not found.")
            return

        # Find the host by name
        host = None
        for h in cluster.host:
            if h.name == host_name:
                host = h
                break

        if not host:
            print(f"Host '{host_name}' not found in cluster '{cluster_name}'.")
            return

        # Find the template by name
        template = None
        for vm in datacenter.vmFolder.childEntity:
            if vm.name == template_name:
                template = vm
                break

        if not template:
            print(f"Template '{template_name}' not found.")
            return

        # Create VM clone specification
        vm_clone_spec = vim.vm.CloneSpec()
        vm_clone_spec.location = vim.vm.RelocateSpec(datastore=datastore, pool=host.parent.resourcePool)
        vm_clone_spec.powerOn = False

        # Clone the VM from the template
        task = template.Clone(folder=datacenter.vmFolder, name=vm_name, spec=vm_clone_spec)

        # Wait for the VM creation task to complete
        while task.info.state not in (vim.TaskInfo.State.success, vim.TaskInfo.State.error):
            pass

        if task.info.state == vim.TaskInfo.State.success:
            print(f"Virtual machine '{vm_name}' created successfully.")
        else:
            print(f"Failed to create virtual machine '{vm_name}'.")
            if task.info.error:
                print(f"Error: {task.info.error}")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

    finally:
        # Disconnect from the vCenter server
        if si:
            connect.Disconnect(si)

if __name__ == "__main__":
    vm_name = "New_VM_Name"
    template_name = "Template_Name"
    datastore_name = "datastore"
    cluster_name = None
    host_name = "192.168.20.55"

    vcenter_host = "192.168.20.60"
    vcenter_user = "administrator@vsphere.local"
    vcenter_password = "Class@100"
    vm_name = "redhat"


    create_vm(vm_name, template_name, datastore_name, cluster_name, host_name, vcenter_host, vcenter_user, vcenter_password)
