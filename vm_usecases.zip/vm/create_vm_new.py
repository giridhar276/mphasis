from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Virtual machine configuration
vm_name = "centos"
datastore_name = "datastore"  # Replace with your datastore name
vm_folder_name = "vm"     # Replace with your desired folder name
cluster_name = None            # Replace with your cluster name
resource_pool_name = "Resources"  # Replace with your resource pool name
template_name = "ubuntu"   # Replace with the name of the VM template to clone from

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to create a basic virtual machine
def create_basic_vm():
    content = service_instance.RetrieveContent()

    # Find the virtual machine template
    template_vm = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )

    for vm in container.view:
        if vm.name == template_name:
            template_vm = vm
            break

    if template_vm is None:
        print(f"Template '{template_name}' not found.")
        return

    # Specify the virtual machine configuration
    vm_config = vim.vm.ConfigSpec()
    vm_config.name = vm_name
    vm_config.memoryMB = 1024  # Memory in MB
    vm_config.numCPUs = 1      # Number of CPUs

    # Create a virtual machine clone task
    try:
        clone_spec = vim.vm.CloneSpec(
            location=vim.vm.RelocateSpec(
                datastoreName=datastore_name,
                poolName=resource_pool_name
            ),
            config=vm_config,
            powerOn=False,  # Change to True if you want to power on the VM immediately
            template=False  # Change to True if you want to create a template
        )
        
        clone_task = template_vm.Clone(
            name=vm_name,
            folder=content.rootFolder.childEntity[0],  # VM folder
            spec=clone_spec
        )
        
        # Monitor the clone task
        while clone_task.info.state == vim.TaskInfo.State.running:
            continue

        if clone_task.info.state == vim.TaskInfo.State.success:
            print(f"Virtual machine '{vm_name}' created successfully.")
        else:
            print(f"Failed to create '{vm_name}': {clone_task.info.error.msg}")

    except Exception as e:
        print(f"Error: {str(e)}")

# Call the function to create the basic virtual machine
create_basic_vm()

# Disconnect from the vCenter Server
Disconnect(service_instance)
