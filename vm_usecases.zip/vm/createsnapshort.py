

from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Virtual machine details
vm_name = "centos"
snapshot_name = "centosbackup"
description = "backup of centos"

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to create a snapshot of a virtual machine
def create_vm_snapshot(vm_name, snapshot_name, description=""):
    content = service_instance.RetrieveContent()

    # Search for the virtual machine by name
    vm = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )
    
    for managed_object_ref in container.view:
        if managed_object_ref.name == vm_name:
            vm = managed_object_ref
            break

    if vm is None:
        print(f"Virtual machine '{vm_name}' not found.")
        return

    # Create a snapshot task
    snapshot_task = vm.CreateSnapshot_Task(
        name=snapshot_name,
        description=description,
        memory=False,
        quiesce=False
    )

    # Monitor the snapshot task
    while snapshot_task.info.state == vim.TaskInfo.State.running:
        continue

    if snapshot_task.info.state == vim.TaskInfo.State.success:
        print(f"Snapshot '{snapshot_name}' created successfully.")
    else:
        print(f"Snapshot creation failed: {snapshot_task.info.error.msg}")

# Call the function to create a snapshot
create_vm_snapshot(vm_name, snapshot_name, description)

# Disconnect from the vCenter Server
Disconnect(service_instance)
