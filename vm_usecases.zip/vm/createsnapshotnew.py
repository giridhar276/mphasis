## display all the virtual machine names available
from pyVim import connect
from pyVmomi import vim
try:
    service_instance = connect.SmartConnect(host='192.168.20.60',
                                            user='administrator@vsphere.local',
                                            pwd='Class@100',
                                            port=443)
    #print(service_instance)
    # this line retrieves the content of the vsphere service instance
    # retrieveContent method provides acccess to the vsphere inventory and various
    # management objects
    content = service_instance.RetrieveContent()
    vm = None
    vm_name = "centos"
    snapshot_name = "centosbackup1giri1"
    # here we search for a vm object in  the vsphere inventory by its name
    #vm = content.searchIndex.FindByInventoryPath(vm_name)
    
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for item in container.view:
        if item.name == vm_name:
            vm = item
            break
    
    # create snapshot
    snapshot_task = vm.CreateSnapshot(name = snapshot_name,
                                      description = 'snapshort created using library',
                                      memory = False,
                                      quiesce  = False)
    print(snapshot_task)
    #taskinfo = snopshot_task.info.result
    #print(taskinfo)

    
    connect.Disconnect(service_instance)
except Exception as err:
    print(err)