from pyVim import connect
from pyVmomi import vim

# vCenter server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# VM configuration parameters
vm_name = 'centos1'
datacenter_name = 'Datacenter'
cluster_name = 'Cluster'
resource_pool_name = 'Resources'
datastore_name = 'YourDatastore'

# Connect to the vCenter server
service_instance = connect.SmartConnect(host=vcenter_host,
                                        user=vcenter_user,
                                        pwd=vcenter_password)

# Retrieve the necessary managed objects
content = service_instance.RetrieveContent()
datacenter = content.rootFolder.childEntity[0]
cluster = datacenter.hostFolder.childEntity[0]
resource_pool = cluster.resourcePool
datastore = datacenter.datastore[0]

# VM configuration
vm_folder = datacenter.vmFolder.childEntity[0]
config_spec = vim.vm.ConfigSpec()
config_spec.name = vm_name
config_spec.memoryMB = 1024  # Memory in MB
config_spec.numCPUs = 2
config_spec.numCoresPerSocket = 1

# Create VM
try:
    vm_clone_spec = vim.vm.CloneSpec()
    vm_clone_spec.location = vim.vm.RelocateSpec()
    vm_clone_spec.location.datastore = datastore
    vm_clone_spec.powerOn = False
    vm_clone_spec.template = False  # This is not a template
    vm_clone_spec.config = config_spec

    task = vm_folder.CreateVM_Task(config=vm_clone_spec, pool=resource_pool)
    print(f"Creating VM '{vm_name}'...")

    # Wait for the VM creation to complete
    task_info = task.info
    while task_info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
        pass

    if task_info.state == vim.TaskInfo.State.success:
        print(f"VM '{vm_name}' created successfully.")
    else:
        print(f"Failed to create VM '{vm_name}': {task_info.error}")
except Exception as e:
    print(f"Error creating VM '{vm_name}': {str(e)}")

# Disconnect from the vCenter server
connect.Disconnect(service_instance)
