from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification (use only for testing, not recommended for production)
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Virtual machine configuration
vm_name = "MyNewVM"
datastore_name = "datastore"  # Replace with your datastore name
datacenter_name = "Datacenter"  # Replace with your datacenter name
template_name = "centos"   # Replace with the name of the VM to clone from

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to create a virtual machine by cloning from a template or VM
def create_vm_by_clone():
    content = service_instance.RetrieveContent()

    # Find the datacenter where you want to create the VM
    datacenter = None
    for entity in content.rootFolder.childEntity:
        if isinstance(entity, vim.Datacenter) and entity.name == datacenter_name:
            datacenter = entity
            break

    if not datacenter:
        print(f"Datacenter '{datacenter_name}' not found.")
        return

    # Find the template or VM to clone from
    template_vm = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )

    for vm in container.view:
        if vm.name == template_name:
            template_vm = vm
            break

    if template_vm is None:
        print(f"Template or VM '{template_name}' not found.")
        return

    # Specify the virtual machine configuration
    vm_config = vim.vm.ConfigSpec()
    vm_config.name = vm_name
    vm_config.memoryMB = 1024  # Memory in MB
    vm_config.numCPUs = 2      # Number of CPUs

    # Create a virtual machine clone task
    try:
        clone_spec = vim.vm.CloneSpec(
            location=vim.vm.RelocateSpec(
                datastoreName=datastore_name
            ),
            config=vm_config,
            powerOn=False,  # Change to True if you want to power on the VM immediately
            template=False  # Change to True if you want to create a template
        )

        clone_task = template_vm.Clone(
            name=vm_name,
            folder=template_vm.parent,  # Use the parent folder of the template
            spec=clone_spec
        )

        # Monitor the clone task
        while clone_task.info.state == vim.TaskInfo.State.running:
            continue

        if clone_task.info.state == vim.TaskInfo.State.success:
            print(f"Virtual machine '{vm_name}' created successfully.")
        else:
            print(f"Failed to create '{vm_name}': {clone_task.info.error.msg}")

    except Exception as e:
        print(f"Error: {str(e)}")

# Call the function to create the VM by cloning
create_vm_by_clone()

# Disconnect from the vCenter Server
Disconnect(service_instance)
