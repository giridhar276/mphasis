from pyVim import connect
from pyVmomi import vim
import atexit

def delete_vm(vcenter_ip, username, password, vm_name):
    try:
        # Connect to the vCenter server
        service_instance = connect.SmartConnect(host=vcenter_ip, user=username, pwd=password)
        atexit.register(connect.Disconnect, service_instance)

        # Find the VM object by name
        content = service_instance.RetrieveContent()
        vm = None
        for vm_folder in content.rootFolder.childEntity:
            if hasattr(vm_folder, 'vmFolder'):
                vm_list = vm_folder.vmFolder.childEntity
                for vm_obj in vm_list:
                    if isinstance(vm_obj, vim.VirtualMachine) and vm_obj.name == vm_name:
                        vm = vm_obj
                        break

        if vm:
            # Power off the VM (if it's powered on)
            if vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOn:
                print(f"Powering off VM '{vm_name}'...")
                task = vm.PowerOff()
                while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
                    pass

            # Destroy the VM
            print(f"Deleting VM '{vm_name}'...")
            task = vm.Destroy()
            while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
                pass

            if task.info.state == vim.TaskInfo.State.success:
                print(f"VM '{vm_name}' deleted successfully.")
            else:
                print(f"VM deletion failed with task state: {task.info.state}")
        else:
            print(f"VM '{vm_name}' not found.")

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    vcenter_ip = "192.168.20.60"
    username = "administrator@vsphere.local"
    password = "Class@100"
    vm_name = "ubuntu"

    delete_vm(vcenter_ip, username, password, vm_name)
