from pyVim import connect
from pyVmomi import vim
import time

def delete_vm_snapshot(vm_name, snapshot_name):
    try:
        # Connect to the vSphere server
        service_instance = connect.SmartConnect(host='192.168.20.60',
                                            user='administrator@vsphere.local',
                                            pwd='Class@100',
                                            port=443)

        # Retrieve a VM object by name
        content = service_instance.RetrieveContent()
        vm = None
        container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
        for item in container.view:
            if item.name == vm_name:
                vm = item
                break



        # Find the snapshot by name
        snapshot = None
        for sn in vm.snapshot.rootSnapshotList:
            print(sn)
            if sn.name == snapshot_name:
                snapshot = sn
                break


        # Delete the snapshot
        task = snapshot.snapshot.RemoveSnapshot_Task(removeChildren=False)

        print("snapshot deleted")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        # Disconnect from the vSphere server
        if service_instance:
            connect.Disconnect(service_instance)

# Replace these with your VM and vSphere server details
vm_name = "centos"
snapshot_name = "centosbackup1giri1"

# Call the function to delete the snapshot
delete_vm_snapshot(vm_name, snapshot_name)
