from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

'''
# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE
'''
# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Connect to the vCenter Server
#This code establishes a connection to the vCenter Server using the SmartConnect function. It uses the provided hostname (vcenter_host), username (vcenter_user), password (vcenter_password), port 443 (the default for HTTPS), and the SSL context we created earlier to connect securely.
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
 #   sslContext=context
)

# Function to list datastores in a datastore cluster
'''
Here, we define a function named list_datastores_in_cluster that takes a parameter cluster_name. Inside the function, we retrieve the content of the vCenter Server using service_instance.RetrieveContent(). This content object provides access to various vSphere objects and properties.
'''
def list_datastores_in_cluster(cluster_name):
    content = service_instance.RetrieveContent()

    '''   
    We create a container view to search for the datastore cluster by name. The CreateContainerView method takes three arguments:
    content.rootFolder: The root folder of the vCenter inventory.
    [vim.StoragePod]: A list of object types to include in the view (in this case, we're interested in vim.StoragePod objects, which represent datastore clusters).
    True: This argument specifies whether to recursively search through child objects.
    '''    
    # Search for the datastore cluster by name
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.StoragePod], True
    )

    '''
    This code iterates through the objects in the container view. For each object, 
    it checks if the object's name matches the specified cluster_name. 
    If a matching datastore cluster is found, it prints the cluster's name and then iterates 
    through the childEntity objects (datastores) within the cluster, printing their names.
    '''

    for cluster in container.view:
        if cluster.name == cluster_name:
            print(f"Datastores in Datastore Cluster '{cluster_name}':")
            for datastore in cluster.childEntity:
                print(f"- {datastore.name}")
            return
    #If no matching datastore cluster is found, this line prints a message indicating that the specified cluster name was not found.
    print(f"Datastore Cluster '{cluster_name}' not found.")

# Specify the name of the datastore cluster you want to list
datastore_cluster_name = "Your_Datastore_Cluster_Name"

# Call the function to list datastores in the specified cluster
list_datastores_in_cluster(datastore_cluster_name)

# Disconnect from the vCenter Server
Disconnect(service_instance)
