from pyVim import connect
from pyVmomi import vim

# Define your vCenter or ESXi server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Connect to the vCenter or ESXi server
service_instance = connect.SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password
)

# Get the root folder of the datacenter
content = service_instance.RetrieveContent()
root_folder = content.rootFolder

# Recursive function to collect VM info
def get_vm_info(folder):
    vm_list = folder.childEntity
    for vm in vm_list:
        if isinstance(vm, vim.Folder):
            get_vm_info(vm)
        elif isinstance(vm, vim.VirtualMachine):
            print(f"VM Name: {vm.name}")
            print(f"   Guest OS: {vm.summary.config.guestFullName}")
            print(f"   Power State: {vm.runtime.powerState}")
            print(f"   CPU Count: {vm.config.hardware.numCPU}")
            print(f"   Memory Size (MB): {vm.config.hardware.memoryMB}")
            print(f"   Host: {vm.runtime.host.name}")
            print("")

# Start retrieving VM info from the root folder
get_vm_info(root_folder)

# Disconnect from the vCenter or ESXi server
connect.Disconnect(service_instance)
