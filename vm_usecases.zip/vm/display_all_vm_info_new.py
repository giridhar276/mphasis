

from pyVim import connect
from pyVmomi import vim

# Define your vCenter or ESXi server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Connect to the vCenter or ESXi server
service_instance = connect.SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password
)

# Get the content and root folder of the datacenter
content = service_instance.RetrieveContent()
datacenter = content.rootFolder.childEntity[0]  # Assuming only one datacenter

# Get a list of all VMs in the datacenter
vm_view = content.viewManager.CreateContainerView(
    datacenter,
    [vim.VirtualMachine],
    True  # Recurse into folders
)

vms = vm_view.view

# Print information about each VM
for vm in vms:
    print(f"VM Name: {vm.name}")
    print(f"   Guest OS: {vm.config.guestFullName}")
    print(f"   Power State: {vm.runtime.powerState}")
    print(f"   CPU Count: {vm.config.hardware.numCPU}")
    print(f"   Memory Size (MB): {vm.config.hardware.memoryMB}")
    print(f"   Host: {vm.runtime.host.name}")
    print("")

# Disconnect from the vCenter or ESXi server
connect.Disconnect(service_instance)
