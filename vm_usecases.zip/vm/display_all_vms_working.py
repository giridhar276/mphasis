## display all the virtual machine names available

from pyVim import connect
from pyVmomi import vim

try:
    service_instance = connect.SmartConnect(host='192.168.20.60',
                                            user='administrator@vsphere.local',
                                            pwd='Class@100',
                                            port=443)
    #print(service_instance)
    # this line retrieves the content of the vsphere service instance
    # retrieveContent method provides acccess to the vsphere inventory and various
    # management objects
    content = service_instance.RetrieveContent()
    
    # retrieve a list of all VMs in the inventory
    # we create a view to list all the virutal machines in the vsphere inventory.
    #createContainerView method is used to specify that we want to view objects.
    # vm_view is object view
    vm_view = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    
    #will iterate through the virual machines in the vm_view container
    for vm in vm_view.view:
        print("VM name :",vm.name)
    
    
    connect.Disconnect(service_instance)
except Exception as err:
    print(err)