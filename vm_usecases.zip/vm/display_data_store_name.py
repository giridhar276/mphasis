import atexit
import sys
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim

# Set your vSphere server connection information
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Connect to vCenter server
si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, port=443)

if not si:
    print("Failed to connect to vCenter server")
    sys.exit(1)

#atexit.register(Disconnect, si)

# Retrieve the root folder of the datacenter
content = si.content
root_folder = content.rootFolder

# List all datastores in the datacenter
datastores = content.viewManager.CreateContainerView(
    root_folder, [vim.Datastore], True).view

# Iterate through datastores and print their names
for datastore in datastores:
    print("Datastore Name:", datastore.name)

# Disconnect from vCenter server
Disconnect(si)
