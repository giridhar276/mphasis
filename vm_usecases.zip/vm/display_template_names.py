from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to retrieve template names
def get_template_names(content):
    template_names = []

    # Create a view of all virtual machines
    vm_view = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    ).view

    # Iterate through virtual machines and collect template names
    for vm in vm_view:
        if vm.config and vm.config.template:
            template_names.append(vm.name)

    return template_names

# Retrieve content from the service instance
content = service_instance.RetrieveContent()

# Get template names
template_names = get_template_names(content)

# Display template names
if template_names:
    print("Template Names:")
    for template_name in template_names:
        print(template_name)
else:
    print("No templates found.")

# Disconnect from the vCenter Server
Disconnect(service_instance)
