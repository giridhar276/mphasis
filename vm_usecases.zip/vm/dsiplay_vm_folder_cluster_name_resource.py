from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import sys

# Set your vSphere server connection information
# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Connect to vCenter server
si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, port=443)

if not si:
    print("Failed to connect to vCenter server")
    sys.exit(1)

# Retrieve the root folder of the datacenter
content = si.content
root_folder = content.rootFolder

# Create a view of all VMs in the datacenter
vm_view = content.viewManager.CreateContainerView(
    root_folder, [vim.VirtualMachine], True).view

# Iterate through VMs and display folder, cluster, and resource pool names
for vm in vm_view:
    # Retrieve the VM's parent folder
    vm_folder = vm.parent
    if isinstance(vm_folder, vim.Folder):
        vm_folder_name = vm_folder.name
    else:
        vm_folder_name = None

    # Retrieve the VM's parent cluster
    vm_cluster = vm.resourcePool.owner
    if isinstance(vm_cluster, vim.ClusterComputeResource):
        vm_cluster_name = vm_cluster.name
    else:
        vm_cluster_name = None

    # Retrieve the VM's resource pool
    vm_resource_pool = vm.resourcePool
    if isinstance(vm_resource_pool, vim.ResourcePool):
        vm_resource_pool_name = vm_resource_pool.name
    else:
        vm_resource_pool_name = None

    # Display the results
    print("VM Name:", vm.name)
    print("VM Folder Name:", vm_folder_name)
    print("Cluster Name:", vm_cluster_name)
    print("Resource Pool Name:", vm_resource_pool_name)
    print("\n")

# Disconnect from vCenter server
Disconnect(si)
