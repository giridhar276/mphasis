from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification (use only for testing, not recommended for production)
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

# Function to find and display datacenter names
def find_datacenter_names(content):
    datacenter_names = []

    # Create a view of all datacenters
    datacenter_view = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.Datacenter], True
    ).view

    # Iterate through datacenters and collect their names
    for datacenter in datacenter_view:
        datacenter_names.append(datacenter.name)

    return datacenter_names

# Retrieve content from the service instance
content = service_instance.RetrieveContent()

# Get datacenter names
datacenter_names = find_datacenter_names(content)

# Display datacenter names
if datacenter_names:
    print("Datacenter Names:")
    for datacenter_name in datacenter_names:
        print(datacenter_name)
else:
    print("No datacenters found.")

# Disconnect from the vCenter Server
Disconnect(service_instance)
