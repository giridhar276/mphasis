from cryptography.fernet import Fernet
import os
key = Fernet.generate_key()
print(key)
############## creating the key and writing the key to key.key
file = open('key.key', 'wb')
file.write(key) # The key is type bytes still
file.close()