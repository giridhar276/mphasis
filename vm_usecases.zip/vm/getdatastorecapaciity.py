## display all the virtual machine names available
from pyVim import connect
from pyVmomi import vim
try:
    service_instance = connect.SmartConnect(host='192.168.20.60',
                                            user='administrator@vsphere.local',
                                            pwd='Class@100',
                                            port=443)
    #print(service_instance)
    # this line retrieves the content of the vsphere service instance
    # retrieveContent method provides acccess to the vsphere inventory and various
    # management objects
    content = service_instance.RetrieveContent()
    vm = None
    vm_name = "centos"
    snapshot_name = "centosbackup1giri1"
    # here we search for a vm object in  the vsphere inventory by its name
    #vm = content.searchIndex.FindByInventoryPath(vm_name)
    
    datastore_view = content.viewManager.CreateContainerView(content.rootFolder, [vim.Datastore], True)
    
    datastore = None
    for ds in datastore_view.view:
        if ds.name == "datastore":
            datastore = ds
            break

    print(datastore.name)
    print("Data store capacity ;",datastore.summary.capacity)
    print("Free Space",datastore.summary.freeSpace)
    

    connect.Disconnect(service_instance)
except Exception as err:
    print(err)