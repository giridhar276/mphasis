from pyVim import connect

# Define your vCenter or ESXi server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@10011"


try:
    # Connect to the vCenter or ESXi server
    service_instance = connect.SmartConnect(
        host=vcenter_host,
        user=vcenter_user,
        pwd=vcenter_password
    )

    # Successfully connected, print an encouragement message
    print("Welcome to the VMware community! We're glad you're here.")
    # Disconnect from the vCenter or ESXi server
    connect.Disconnect(service_instance)
except Exception as e:
    # Handle any authentication or connection errors
    print(f"Error connecting to VMware: {str(e)}")
