

def displayName():
    print("hostname :",'centos')
    
def displayDatacenter():
    print("Datacenter :","datacenter")

def displayPort():
    print("Port numbere :",443)


# this condition will be always True if this code is executed directly
# if this program is ipmorted to some other program it comes False
if __name__ == "__main__":
    displayName()
    displayDatacenter()
    displayPort()    