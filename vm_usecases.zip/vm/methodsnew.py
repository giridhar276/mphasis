import methods


methods.displayDatacenter()
methods.displayName()
methods.displayPort()