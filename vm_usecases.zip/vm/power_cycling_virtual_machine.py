
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import atexit
import sys
import time

def connect_to_vcenter(host, user, password):
    try:
        service_instance = SmartConnect(host=host, user=user, pwd=password, port=443)
        atexit.register(Disconnect, service_instance)
        return service_instance.RetrieveContent()
    except Exception as e:
        print(f"Error connecting to vCenter: {str(e)}")
        sys.exit(1)

def power_cycle_vm(vm):
    try:
        # Check the VM's power state
        if vm.runtime.powerState == vim.VirtualMachinePowerState.poweredOn:
            print(f"Powering off VM '{vm.name}'...")
            task = vm.PowerOff()
            WaitForTask(task)

        # Power on the VM
        print(f"Powering on VM '{vm.name}'...")
        task = vm.PowerOn()
        WaitForTask(task)

        print(f"VM '{vm.name}' power cycled successfully.")
    except Exception as e:
        print(f"Error power cycling VM '{vm.name}': {str(e)}")

def WaitForTask(task):
    while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
        time.sleep(1)

    if task.info.state == vim.TaskInfo.State.success:
        return task.info.result
    elif task.info.state == vim.TaskInfo.State.error:
        print(f"Task failed: {task.info.error.msg}")
        return None

def main():
    # Edit these with your vCenter/ESXi server credentials
    vcenter_host = "192.168.20.60"
    vcenter_user = "administrator@vsphere.local"
    vcenter_password = "Class@100"

    # Connect to vCenter server
    content = connect_to_vcenter(vcenter_host, vcenter_user, vcenter_password)

    # Specify the name of the virtual machine you want to power cycle
    vm_name = "win10"

    # Find the virtual machine by name
    vm = None
    vm_view = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for managed_vm in vm_view.view:
        if managed_vm.name == vm_name:
            vm = managed_vm
            break

    if vm:
        # Power cycle the specified virtual machine
        power_cycle_vm(vm)
    else:
        print(f"Virtual machine '{vm_name}' not found.")

if __name__ == "__main__":
    main()
