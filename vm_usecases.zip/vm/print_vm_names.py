from pyVim import connect  # create connection and disconnect
from pyVmomi import vim    # core functionality

# Define your vCenter or ESXi server connection parameters
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# Connect to the vCenter or ESXi server
service_instance = connect.SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password
)

# Recursive function to collect VM names
def get_vm_names(folder):
    vm_list = folder.childEntity
    for entity in vm_list:
        if isinstance(entity, vim.Folder):
            get_vm_names(entity)
        elif isinstance(entity, vim.VirtualMachine):
            #print(f"VM Name: {entity.name}")
            #print("VM Name: {}".format(entity.name))
            print("VM Name: {}".format(entity.name))

# Get the root folder of the datacenter
content = service_instance.RetrieveContent()
for child in content.rootFolder.childEntity:
    if isinstance(child, vim.Datacenter):
        get_vm_names(child.vmFolder)

# Disconnect from the vCenter or ESXi server
connect.Disconnect(service_instance)
