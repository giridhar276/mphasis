

from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"


# Virtual machine details
vm_name = "centos"

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

'''
Here, we define a function named reboot_vm that takes the vm_name as a parameter. 
Inside the function, we retrieve the content of the vCenter Server using service_instance.RetrieveContent(). 
This content object provides access to various vSphere objects and properties.

We then search for the virtual machine by name using a container view. 
If a virtual machine with the specified name is found, we store a reference to it in the vm variable.

If the virtual machine is not found, we print a message indicating that it was not found and return 
from the function.
'''
# Function to reboot a virtual machine
def reboot_vm(vm_name):
    content = service_instance.RetrieveContent()

    # Search for the virtual machine by name
    vm = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, [vim.VirtualMachine], True
    )

    for managed_object_ref in container.view:
        if managed_object_ref.name == vm_name:
            vm = managed_object_ref
            break

    if vm is None:
        print(f"Virtual machine '{vm_name}' not found.")
        return

    # Reboot the virtual machine
    '''
    This section attempts to reboot the virtual machine using the vm.ResetVM_Task() method. It starts the reboot task and monitors it until it completes.
    We print a message indicating that the reboot process has started.
    We use a while loop to continuously check the state of the task. When the task completes, we check whether it was successful or not.
    If the task was successful, we print a success message. If it failed, we print an error message with details about the failure.
    In case of any exceptions, we catch and print the error message.
    '''
    try:
        task = vm.ResetVM_Task()
        print(f"Rebooting '{vm_name}'...")

        # Monitor the reboot task
        while task.info.state == vim.TaskInfo.State.running:
            continue

        if task.info.state == vim.TaskInfo.State.success:
            print(f"Virtual machine '{vm_name}' rebooted successfully.")
        else:
            print(f"Failed to reboot '{vm_name}': {task.info.error.msg}")
    except Exception as e:
        print(f"Error: {str(e)}")

# Call the function to reboot the virtual machine
reboot_vm(vm_name)

# Disconnect from the vCenter Server
Disconnect(service_instance)
