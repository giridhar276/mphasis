# step :list all the vms



from pyVim import connect
from pyVmomi import vim
import ssl

def remove_all_snapshots(vm_name, vcenter_host, vcenter_user, vcenter_password):
    try:


        # Connect to the vCenter server
        si = connect.SmartConnect(host=vcenter_host,
                                  user=vcenter_user,
                                  pwd=vcenter_password,
)

        # Retrieve the content of the vCenter server
        content = si.RetrieveContent()

        # Search for the virtual machine by name
        vm = None
        vm_folder = content.rootFolder
        vm_view = content.viewManager.CreateContainerView(vm_folder, [vim.VirtualMachine], True)

        for child in vm_view.view:
            if child.name == vm_name:
                vm = child
                break

        # Close the view
        vm_view.Destroy()

        # Check if the VM was found
        if vm is None:
            print(f"Virtual machine '{vm_name}' not found.")
            return

        # Check if the virtual machine has snapshots
        if vm.snapshot is not None:
            snapshot_task = vm.RemoveAllSnapshots_Task()
            # Wait for the task to complete
            task_info = snapshot_task.info

            while task_info.state == vim.TaskInfo.State.running:
                task_info = snapshot_task.info
            print("snapshort removed")
        else:
            print(f"No snapshots found for '{vm_name}'.")

        # Disconnect from the vCenter server
        connect.Disconnect(si)

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":

    vcenter_host = "192.168.20.60"
    vcenter_user = "administrator@vsphere.local"
    vcenter_password = "Class@100"
    vm_name = "centos"

    remove_all_snapshots(vm_name, vcenter_host, vcenter_user, vcenter_password)
