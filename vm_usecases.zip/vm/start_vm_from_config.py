# step :list all the vms



from pyVim import connect
from pyVmomi import vim
import ssl
import configparser
from pyVim import connect
from pyVmomi import vim
import ssl


parser = configparser.ConfigParser()
parser.read('credentials.conf')
#print(parser.sections)


def poweron_vm(vm_name, vcenter_host, vcenter_user, vcenter_password):
    try:


        # Connect to the vCenter server
        si = connect.SmartConnect(host=vcenter_host,
                                  user=vcenter_user,
                                  pwd=vcenter_password,
)

        # Retrieve the content of the vCenter server
        content = si.RetrieveContent()

        # Search for the virtual machine by name
        vm = None
        vm_folder = content.rootFolder
        vm_view = content.viewManager.CreateContainerView(vm_folder, [vim.VirtualMachine], True)

        for child in vm_view.view:
            if child.name == vm_name:
                vm = child
                break

        # Close the view
        vm_view.Destroy()

        # Check if the VM was found
        if vm is None:
            print(f"Virtual machine '{vm_name}' not found.")
            return

        ## check if the vm is powered on or not
        task = vm.PowerOn()
        print("powering the virtual machine")

        # Disconnect from the vCenter server
        connect.Disconnect(si)

    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":

    vcenter_host = parser.get('vsphere','host')
    vcenter_user = parser.get('vsphere','user')
    vcenter_password = parser.get('vsphere','password')
    vm_name = parser.get('vsphere','name')
    
    poweron_vm(vm_name, vcenter_host, vcenter_user, vcenter_password)
