from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

# Disable SSL certificate verification
context = ssl.SSLContext(ssl.PROTOCOL_TLS)
context.verify_mode = ssl.CERT_NONE

# vCenter Server connection details
vcenter_host = "192.168.20.60"
vcenter_user = "administrator@vsphere.local"
vcenter_password = "Class@100"

# VM name to check
vm_name_to_check = "centos"

# Connect to the vCenter Server
service_instance = SmartConnect(
    host=vcenter_host,
    user=vcenter_user,
    pwd=vcenter_password,
    port=443,
    sslContext=context
)

def is_vm_a_template(vm):
    """
    Check if a VM is a template.
    :param vm: VM object to check.
    :return: True if the VM is a template, False otherwise.
    """
    return vm.config.template

# Retrieve content from the service instance
content = service_instance.RetrieveContent()

# Find the VM by name
vm_view = content.viewManager.CreateContainerView(
    content.rootFolder, [vim.VirtualMachine], True
).view

target_vm = None
for vm in vm_view:
    if vm.name == vm_name_to_check:
        target_vm = vm
        break

# Check if the VM is a template
if target_vm:
    if is_vm_a_template(target_vm):
        print(f"'{vm_name_to_check}' is a template.")
    else:
        print(f"'{vm_name_to_check}' is not a template.")
else:
    print(f"VM '{vm_name_to_check}' not found.")

# Disconnect from the vCenter Server
Disconnect(service_instance)
